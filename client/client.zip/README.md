This project was bootstrapped with [Create React App](https://github.com/facebook/create-react-app).

## Available Scripts

In the project directory, you can run:
<!-- 
### `npm run start` -->
1. clone or download repo
2. run `npm install` inside backend folder
3. run `npm run start` inside backend folder
4. run `npm install` inside client folder
5. run `npm run start` inside client folder
6. Open [http://localhost:3000](http://localhost:3000) to view it in the browser.



