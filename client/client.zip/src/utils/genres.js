export const genres = ['', 'action', 'adventure', 'animation', 'biography', 'comedy', 'crime',
    'documentary', 'drama', 'family', 'fantasy', 'fantasy', 'film-noir', 'history', 'horror',
    'musical', 'mystery', 'romance', 'sci-fi', 'sport', 'thriller', 'war', 'western'
]